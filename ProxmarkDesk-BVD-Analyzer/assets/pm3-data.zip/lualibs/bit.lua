-- ProxmarkDesk: trace_parse needs band/rshift; Iceman supplies bit32.
assert(bit32, "Iceman bit32 compatibility module unavailable")
return bit32
