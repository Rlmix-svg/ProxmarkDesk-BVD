-- ProxmarkDesk read-only environment test
local paths = {}
paths[#paths+1] = "lualibs/7816_error.lua"
paths[#paths+1] = "lualibs/amiibo_tools.lua"
paths[#paths+1] = "lualibs/ansicolors.lua"
paths[#paths+1] = "lualibs/bit.lua"
paths[#paths+1] = "lualibs/commands.lua"
paths[#paths+1] = "lualibs/default_toys.lua"
paths[#paths+1] = "lualibs/default_toys_di.lua"
paths[#paths+1] = "lualibs/dkjson.lua"
paths[#paths+1] = "lualibs/getopt.lua"
paths[#paths+1] = "lualibs/hf_reader.lua"
paths[#paths+1] = "lualibs/html_dumplib.lua"
paths[#paths+1] = "lualibs/htmlskel.lua"
paths[#paths+1] = "lualibs/md5.lua"
paths[#paths+1] = "lualibs/mfc_default_keys.lua"
paths[#paths+1] = "lualibs/pm3_cmd.lua"
paths[#paths+1] = "lualibs/precalc.lua"
paths[#paths+1] = "lualibs/read14a.lua"
paths[#paths+1] = "lualibs/read14b.lua"
paths[#paths+1] = "lualibs/read15.lua"
paths[#paths+1] = "lualibs/t55xx_config.lua"
paths[#paths+1] = "lualibs/taglib.lua"
paths[#paths+1] = "lualibs/testresult.lua"
paths[#paths+1] = "lualibs/trace_parse.lua"
paths[#paths+1] = "lualibs/utils.lua"
paths[#paths+1] = "luascripts/data_hex_crc.lua"
paths[#paths+1] = "luascripts/data_mf_accessdecode.lua"
paths[#paths+1] = "luascripts/data_mf_bin2eml.lua"
paths[#paths+1] = "luascripts/data_mf_bin2html.lua"
paths[#paths+1] = "luascripts/data_mf_eml2bin.lua"
paths[#paths+1] = "luascripts/data_mf_eml2html.lua"
paths[#paths+1] = "luascripts/data_mfu_bin2eml.lua"
paths[#paths+1] = "luascripts/examples/example_cmdline.lua"
paths[#paths+1] = "luascripts/examples/example_parameters.lua"
paths[#paths+1] = "luascripts/hf_14a_aztek.lua"
paths[#paths+1] = "luascripts/hf_14a_i2crevive.lua"
paths[#paths+1] = "luascripts/hf_14a_protectimus_nfc.lua"
paths[#paths+1] = "luascripts/hf_14a_raw.lua"
paths[#paths+1] = "luascripts/hf_14a_read_ltocm.lua"
paths[#paths+1] = "luascripts/hf_14b_calypso.lua"
paths[#paths+1] = "luascripts/hf_14b_mobib.lua"
paths[#paths+1] = "luascripts/hf_15_magic.lua"
paths[#paths+1] = "luascripts/hf_i2c_plus_2k_utils.lua"
paths[#paths+1] = "luascripts/hf_legic.lua"
paths[#paths+1] = "luascripts/hf_legic_buffer2card.lua"
paths[#paths+1] = "luascripts/hf_legic_clone.lua"
paths[#paths+1] = "luascripts/hf_mf_autopwn.lua"
paths[#paths+1] = "luascripts/hf_mf_dump_luxeo.lua"
paths[#paths+1] = "luascripts/hf_mf_em_util.lua"
paths[#paths+1] = "luascripts/hf_mf_format.lua"
paths[#paths+1] = "luascripts/hf_mf_gen3_writer.lua"
paths[#paths+1] = "luascripts/hf_mf_keycheck.lua"
paths[#paths+1] = "luascripts/hf_mf_magicrevive.lua"
paths[#paths+1] = "luascripts/hf_mf_mini_dumpdecrypt.lua"
paths[#paths+1] = "luascripts/hf_mf_sim_hid.lua"
paths[#paths+1] = "luascripts/hf_mf_tnp3_clone.lua"
paths[#paths+1] = "luascripts/hf_mf_tnp3_dump.lua"
paths[#paths+1] = "luascripts/hf_mf_tnp3_sim.lua"
paths[#paths+1] = "luascripts/hf_mf_uid_downgrade.lua"
paths[#paths+1] = "luascripts/hf_mf_uidbruteforce.lua"
paths[#paths+1] = "luascripts/hf_mf_uidkeycalc.lua"
paths[#paths+1] = "luascripts/hf_mf_uidkeycalc_mizip.lua"
paths[#paths+1] = "luascripts/hf_mf_ultimatecard.lua"
paths[#paths+1] = "luascripts/hf_mf_uscuid_prog.lua"
paths[#paths+1] = "luascripts/hf_mfp_raw.lua"
paths[#paths+1] = "luascripts/hf_mfu_amiibo_restore.lua"
paths[#paths+1] = "luascripts/hf_mfu_amiibo_sim.lua"
paths[#paths+1] = "luascripts/hf_mfu_magicwrite.lua"
paths[#paths+1] = "luascripts/hf_mfu_pwdgen_italy.lua"
paths[#paths+1] = "luascripts/hf_mfu_setuid.lua"
paths[#paths+1] = "luascripts/hf_mfu_ultra.lua"
paths[#paths+1] = "luascripts/hf_ndef_dump.lua"
paths[#paths+1] = "luascripts/hf_ntag_3d.lua"
paths[#paths+1] = "luascripts/hf_ntag_bruteforce.lua"
paths[#paths+1] = "luascripts/hf_ntag_dt.lua"
paths[#paths+1] = "luascripts/init_rdv4.lua"
paths[#paths+1] = "luascripts/lf_awid_bulkclone.lua"
paths[#paths+1] = "luascripts/lf_electra.lua"
paths[#paths+1] = "luascripts/lf_em4100_bulk.lua"
paths[#paths+1] = "luascripts/lf_em4x05_kybercrystals.lua"
paths[#paths+1] = "luascripts/lf_em_tearoff.lua"
paths[#paths+1] = "luascripts/lf_em_tearoff_protect.lua"
paths[#paths+1] = "luascripts/lf_hid_bulkclone.lua"
paths[#paths+1] = "luascripts/lf_hid_bulkclone_v2.lua"
paths[#paths+1] = "luascripts/lf_ht2_paxton.lua"
paths[#paths+1] = "luascripts/lf_ident_json.lua"
paths[#paths+1] = "luascripts/lf_ioprox_bulkclone.lua"
paths[#paths+1] = "luascripts/lf_t55xx_chk.lua"
paths[#paths+1] = "luascripts/lf_t55xx_chk_date.lua"
paths[#paths+1] = "luascripts/lf_t55xx_fix.lua"
paths[#paths+1] = "luascripts/lf_t55xx_multiwriter.lua"
paths[#paths+1] = "luascripts/lf_t55xx_reset.lua"
paths[#paths+1] = "luascripts/mem_readpwd.lua"
paths[#paths+1] = "luascripts/mem_spiffs_readpwd.lua"
paths[#paths+1] = "luascripts/mfc_hammerlite.lua"
paths[#paths+1] = "luascripts/multi_bruteforce.lua"
paths[#paths+1] = "luascripts/ntag_clean.lua"
paths[#paths+1] = "luascripts/ntag_getsig.lua"
paths[#paths+1] = "luascripts/ntag_hammertime.lua"
paths[#paths+1] = "luascripts/tests/data_tracetest.lua"
paths[#paths+1] = "luascripts/tests/hf_read.lua"
paths[#paths+1] = "luascripts/tests/lf_t55xx_defaultask.lua"
paths[#paths+1] = "luascripts/tests/lf_t55xx_defaultbi.lua"
paths[#paths+1] = "luascripts/tests/lf_t55xx_defaultfsk.lua"
paths[#paths+1] = "luascripts/tests/lf_t55xx_defaultpsk.lua"
paths[#paths+1] = "luascripts/tests/lf_t55xx_writetest.lua"
local loaded, missing, syntax = 0, 0, 0
local base = (os.getenv("HOME") or "") .. "/.proxmark3/"
package.path=base.."lualibs/?.lua;"..base.."luascripts/?.lua"
for _, path in ipairs(paths) do local f,err=loadfile(base..path); if not f then syntax=syntax+1; print("SYNTAX ERROR "..path..": "..tostring(err)) end end
local function denied() error("Operation forbidden during environment check") end
if core then for k,v in pairs(core) do if type(v)=="function" then core[k]=denied end end end
os.execute=denied; io.popen=denied
local open=io.open; io.open=function(path,mode) if mode and mode~="r" and mode~="rb" then denied() end return open(path,mode) end
package.preload["pm3"]=function() return {pm3=denied} end
do local ok,err=pcall(require,"7816_error"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR 7816_error: "..tostring(err)) end end
do local ok,err=pcall(require,"amiibo_tools"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR amiibo_tools: "..tostring(err)) end end
do local ok,err=pcall(require,"ansicolors"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR ansicolors: "..tostring(err)) end end
do local ok,err=pcall(require,"bit"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR bit: "..tostring(err)) end end
do local ok,err=pcall(require,"commands"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR commands: "..tostring(err)) end end
do local ok,err=pcall(require,"default_toys"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR default_toys: "..tostring(err)) end end
do local ok,err=pcall(require,"default_toys_di"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR default_toys_di: "..tostring(err)) end end
do local ok,err=pcall(require,"dkjson"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR dkjson: "..tostring(err)) end end
do local ok,err=pcall(require,"getopt"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR getopt: "..tostring(err)) end end
do local ok,err=pcall(require,"hf_reader"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR hf_reader: "..tostring(err)) end end
do local ok,err=pcall(require,"html_dumplib"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR html_dumplib: "..tostring(err)) end end
do local ok,err=pcall(require,"htmlskel"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR htmlskel: "..tostring(err)) end end
do local ok,err=pcall(require,"md5"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR md5: "..tostring(err)) end end
do local ok,err=pcall(require,"mfc_default_keys"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR mfc_default_keys: "..tostring(err)) end end
do local ok,err=pcall(require,"pm3_cmd"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR pm3_cmd: "..tostring(err)) end end
do local ok,err=pcall(require,"precalc"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR precalc: "..tostring(err)) end end
do local ok,err=pcall(require,"read14a"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR read14a: "..tostring(err)) end end
do local ok,err=pcall(require,"read14b"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR read14b: "..tostring(err)) end end
do local ok,err=pcall(require,"read15"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR read15: "..tostring(err)) end end
do local ok,err=pcall(require,"t55xx_config"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR t55xx_config: "..tostring(err)) end end
do local ok,err=pcall(require,"taglib"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR taglib: "..tostring(err)) end end
do local ok,err=pcall(require,"testresult"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR testresult: "..tostring(err)) end end
do local ok,err=pcall(require,"trace_parse"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR trace_parse: "..tostring(err)) end end
do local ok,err=pcall(require,"utils"); if ok then loaded=loaded+1 else missing=missing+1; print("MODULE ERROR utils: "..tostring(err)) end end
print("Loaded modules: "..loaded)
print("Missing modules: "..missing)
print("Syntax errors: "..syntax)
if missing==0 and syntax==0 then print("Lua environment OK") else print("Lua environment FAILED") end
